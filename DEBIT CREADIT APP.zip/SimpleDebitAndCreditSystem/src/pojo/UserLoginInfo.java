package pojo;

public class UserLoginInfo {
	
	String userName;
	String password;
	String email;
	String role;
	
	public UserLoginInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UserLoginInfo(String userName, String password, String email, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.role = role;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "UserLoginInfo [userName=" + userName + ", password=" + password + "]";
	}
	
}
