package action;

import com.opensymphony.xwork2.ActionSupport;

public class StartpageAction extends ActionSupport{
	
	public String execute() {
		//System.out.println("startpageAction ececute() called");
		
		return "success";
	}
}
